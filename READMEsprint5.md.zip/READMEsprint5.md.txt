Viewing for the sprint 5 project from tableau is addressed in the website, it should be sheets along with dashboards.  Below is the link for the workbook.

https://public.tableau.com/views/Sprint5project/SuperstoreAnalysis?:language=en-US&publish=yes&:sid=&:display_count=n&:origin=viz_share_link


Project presentation through google drive link
https://drive.google.com/file/d/1JtCfw-MIMUlbGobPO1NZNLQqV2Yfrkza/view?usp=sharing