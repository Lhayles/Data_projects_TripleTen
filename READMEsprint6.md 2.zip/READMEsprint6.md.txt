These links should work for the screen shots for the power BI project

https://drive.google.com/file/d/105-V03zENZtXU5Nk4lquywrD2wCG7CvK/view?usp=sharing, https://drive.google.com/file/d/1Bmke8hSqf5rVmobxPPKB77c5A0ASr4VV/view?usp=sharing, https://drive.google.com/file/d/1qH5h1sEOE3y1ds-AH453t-clBQaRSmLy/view?usp=sharing